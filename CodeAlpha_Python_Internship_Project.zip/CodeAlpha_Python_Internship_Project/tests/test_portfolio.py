import unittest
from codealpha.portfolio import calculate_portfolio


class PortfolioTests(unittest.TestCase):
    def test_total_value(self):
        items, total = calculate_portfolio({"AAPL": 2, "TSLA": 1},
                                           {"AAPL": 10, "TSLA": 20})
        self.assertAlmostEqual(total, 40.0)
        self.assertEqual(len(items), 2)

    def test_unknown_symbol_rejected(self):
        with self.assertRaises(ValueError):
            calculate_portfolio({"UNKNOWN": 1}, {"AAPL": 10})

    def test_non_positive_quantity_rejected(self):
        with self.assertRaises(ValueError):
            calculate_portfolio({"AAPL": 0}, {"AAPL": 10})


if __name__ == "__main__":
    unittest.main()
