# CodeAlpha Python Internship Project

A beginner-friendly, menu-driven Python project containing **three internship tasks**:

1. **Hangman Game** – random word selection, letter guesses, and six incorrect-guess limit.
2. **Stock Portfolio Tracker** – calculates a sample portfolio value from manually defined prices. This is an educational calculator, not live market data or investment advice.
3. **Basic Rule-Based Chatbot** – responds to simple greetings, questions, and goodbye messages.

The project uses Python's standard library only. No API keys or paid packages are needed.

## Requirements
- Python 3.8 or later
- Terminal / Command Prompt

## Quick start (easy GitHub upload)
The standalone file `codealpha_internship.py` contains all three tasks in one file. You can upload this single Python file to GitHub if uploading folders from a phone is difficult. Run it with `python codealpha_internship.py`.

## Run the modular project
Open a terminal in this folder and run:

```bash
python main.py
```

On some systems, use `python3 main.py`.

## Run the tests
```bash
python -m unittest discover -s tests -v
```

## Project structure
```text
CodeAlpha_Python_Internship_Project/
├── main.py
├── README.md
├── .gitignore
├── codealpha/
│   ├── __init__.py
│   ├── hangman.py
│   ├── portfolio.py
│   └── chatbot.py
└── tests/
    ├── test_hangman.py
    └── test_portfolio.py
```

## Task details

### Task 1 – Hangman Game
- Selects a word randomly from a small built-in word bank.
- Displays correctly guessed letters and hides the remaining letters.
- Allows up to six incorrect guesses.
- Checks invalid input and repeated guesses.

### Task 2 – Stock Portfolio Tracker
- Uses sample prices stored in a Python dictionary.
- Accepts stock symbols and quantities.
- Calculates each holding and the total portfolio value.
- Can save a simple report to `portfolio_report.txt`.
- Prices are hardcoded examples and are not live quotes.

### Task 4 – Basic Chatbot
- Uses simple keyword/rule matching.
- Supports greetings, asking its name, asking how it is, help, and goodbye.
- Keeps chatting until the user exits.

## GitHub upload
1. Sign in to GitHub and create a **new public repository** named `CodeAlpha_Python_Internship_Project`.
2. Extract this ZIP file.
3. Upload the project files and folders to the repository (or use Git if available).
4. Check that `README.md`, `main.py`, `codealpha/`, and `tests/` appear in the repository.
5. Copy the repository URL and submit that URL in the CodeAlpha submission form.

## Suggested submission description
"I completed three Python programming tasks: Hangman Game, Stock Portfolio Tracker, and Basic Rule-Based Chatbot. The project demonstrates Python fundamentals including loops, conditionals, functions, strings, lists, dictionaries, input/output, and file handling. Source code and instructions are available in this GitHub repository."

## Important
Follow the latest instructions in your official CodeAlpha WhatsApp group and submission form. Completing the project does not guarantee a recommendation letter or certificate; those depend on the organization's review and criteria.
