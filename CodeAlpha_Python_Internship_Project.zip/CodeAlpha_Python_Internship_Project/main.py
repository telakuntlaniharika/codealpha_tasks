"""Main menu for the CodeAlpha Python internship mini-project."""

from codealpha.hangman import play_hangman
from codealpha.portfolio import run_portfolio_tracker
from codealpha.chatbot import run_chatbot


def show_menu():
    print("\n" + "=" * 54)
    print("       CODEALPHA PYTHON INTERNSHIP PROJECT")
    print("=" * 54)
    print("1. Play Hangman Game")
    print("2. Stock Portfolio Tracker")
    print("3. Basic Chatbot")
    print("4. Exit")
    print("-" * 54)


def main():
    print("Welcome! Explore the three Python projects.")
    while True:
        show_menu()
        choice = input("Enter your choice (1-4): ").strip()

        if choice == "1":
            play_hangman()
        elif choice == "2":
            run_portfolio_tracker()
        elif choice == "3":
            run_chatbot()
        elif choice == "4":
            print("Thank you for exploring the project. Goodbye!")
            break
        else:
            print("Please enter a valid option from 1 to 4.")


if __name__ == "__main__":
    main()
