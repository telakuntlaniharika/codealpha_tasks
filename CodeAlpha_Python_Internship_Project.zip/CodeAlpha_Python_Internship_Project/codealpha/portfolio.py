"""Educational stock portfolio value calculator using sample prices."""

STOCK_PRICES = {
    "AAPL": 180.00,
    "TSLA": 250.00,
    "MSFT": 420.00,
    "GOOGL": 165.00,
    "AMZN": 190.00,
}


def calculate_portfolio(holdings, prices=None):
    """Return (line_items, total); each line item is (symbol, quantity, price, value)."""
    prices = prices or STOCK_PRICES
    line_items = []
    total = 0.0

    for symbol, quantity in holdings.items():
        if symbol not in prices:
            raise ValueError(f"Unknown stock symbol: {symbol}")
        if quantity <= 0:
            raise ValueError("Quantity must be greater than zero.")
        price = float(prices[symbol])
        value = price * quantity
        line_items.append((symbol, quantity, price, value))
        total += value

    return line_items, total


def save_report(line_items, total, filename="portfolio_report.txt"):
    with open(filename, "w", encoding="utf-8") as report:
        report.write("SAMPLE STOCK PORTFOLIO REPORT\n")
        report.write("-" * 42 + "\n")
        for symbol, quantity, price, value in line_items:
            report.write(
                f"{symbol}: {quantity} shares x ${price:.2f} = ${value:.2f}\n"
            )
        report.write("-" * 42 + f"\nTotal sample value: ${total:.2f}\n")
        report.write("Note: Hardcoded educational prices; not live market data.\n")


def run_portfolio_tracker():
    print("\n--- STOCK PORTFOLIO TRACKER ---")
    print("Sample prices (USD):")
    for symbol, price in STOCK_PRICES.items():
        print(f"  {symbol}: ${price:.2f}")
    print("Enter quantities. Enter 0 to skip a stock.")

    holdings = {}
    for symbol in STOCK_PRICES:
        while True:
            raw = input(f"Quantity of {symbol}: ").strip()
            try:
                quantity = int(raw)
                if quantity < 0:
                    print("Please enter zero or a positive whole number.")
                    continue
                if quantity:
                    holdings[symbol] = quantity
                break
            except ValueError:
                print("Please enter a whole number.")

    if not holdings:
        print("No stocks selected; portfolio is empty.")
        return

    items, total = calculate_portfolio(holdings)
    print("\nPORTFOLIO SUMMARY")
    print("-" * 48)
    for symbol, quantity, price, value in items:
        print(f"{symbol:<8} {quantity:>5} x ${price:>8.2f} = ${value:>10.2f}")
    print("-" * 48)
    print(f"TOTAL PORTFOLIO VALUE: ${total:.2f}")

    choice = input("Save this report to portfolio_report.txt? (y/n): ").strip().lower()
    if choice == "y":
        save_report(items, total)
        print("Report saved successfully as portfolio_report.txt.")


if __name__ == "__main__":
    run_portfolio_tracker()
