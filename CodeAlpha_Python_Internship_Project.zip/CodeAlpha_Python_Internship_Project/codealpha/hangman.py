"""A simple text-based Hangman game."""

import random

WORDS = ["PYTHON", "COMPUTER", "GITHUB", "PROGRAM", "KEYBOARD"]
MAX_WRONG_GUESSES = 6


def play_hangman():
    secret_word = random.choice(WORDS)
    guessed_letters = set()
    wrong_guesses = 0

    print("\n--- HANGMAN GAME ---")
    print("Guess the hidden word one letter at a time.")
    print(f"You can make up to {MAX_WRONG_GUESSES} incorrect guesses.")

    while wrong_guesses < MAX_WRONG_GUESSES:
        display = " ".join(
            letter if letter in guessed_letters else "_" for letter in secret_word
        )
        print(f"\nWord: {display}")
        print(f"Incorrect guesses left: {MAX_WRONG_GUESSES - wrong_guesses}")
        print("Guessed letters:", ", ".join(sorted(guessed_letters)) or "None")

        if all(letter in guessed_letters for letter in secret_word):
            print(f"Congratulations! You guessed {secret_word}.")
            return True

        guess = input("Enter one alphabet letter: ").strip().upper()
        if len(guess) != 1 or not guess.isalpha():
            print("Invalid input. Enter exactly one alphabet letter.")
            continue
        if guess in guessed_letters:
            print("You already guessed that letter. Try another.")
            continue

        guessed_letters.add(guess)
        if guess in secret_word:
            print("Correct guess!")
        else:
            wrong_guesses += 1
            print("Not in the word.")

    print(f"\nGame over! The word was {secret_word}.")
    return False


if __name__ == "__main__":
    play_hangman()
